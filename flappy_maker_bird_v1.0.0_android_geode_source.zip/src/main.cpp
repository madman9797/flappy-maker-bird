#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/binding/GameManager.hpp>
#include <Geode/binding/MenuLayer.hpp>

using namespace geode::prelude;
using namespace cocos2d;

namespace flappy {

class BirdGameLayer final : public CCLayer {
protected:
    CCNode* m_world = nullptr;
    CCSprite* m_bird = nullptr;
    CCLabelBMFont* m_scoreLabel = nullptr;
    CCLabelBMFont* m_message = nullptr;
    CCMenu* m_buttons = nullptr;

    struct Pipe { float x; float gapY; bool scored; };
    std::vector<Pipe> m_pipes;
    float m_birdY = 0.f;
    float m_velocity = 0.f;
    float m_spawnTimer = 0.f;
    float m_speed = 260.f;
    int m_score = 0;
    bool m_started = false;
    bool m_dead = false;

    static constexpr float kBirdX = 180.f;
    static constexpr float kBirdSize = 28.f;
    static constexpr float kGravity = -950.f;
    static constexpr float kFlap = 350.f;
    static constexpr float kPipeWidth = 70.f;
    static constexpr float kGap = 190.f;

    bool init() override {
        if (!CCLayer::init()) return false;
        this->setTouchEnabled(true);
        this->setKeypadEnabled(true);
        this->scheduleUpdate();

        auto win = CCDirector::sharedDirector()->getWinSize();
        auto bg = CCLayerColor::create(ccColor4B{135, 206, 235, 255});
        this->addChild(bg, -10);

        // Simple ground.
        auto ground = CCLayerColor::create(ccColor4B{80, 180, 70, 255}, win.width, 55.f);
        ground->setPosition(0, 0);
        this->addChild(ground, -5);

        m_world = CCNode::create();
        this->addChild(m_world, 1);

        // Use the normal GD player sprite as the bird base. This keeps the player's icon visible.
        m_bird = CCSprite::createWithSpriteFrameName("player_1_001.png");
        if (!m_bird) m_bird = CCSprite::create("GJ_GameSheet02.png");
        if (m_bird) {
            m_bird->setPosition(kBirdX, win.height * .5f);
            m_bird->setScale(.65f);
            m_world->addChild(m_bird, 5);
            m_birdY = m_bird->getPositionY();
        }

        m_scoreLabel = CCLabelBMFont::create("0", "bigFont.fnt");
        m_scoreLabel->setPosition(win.width / 2.f, win.height - 55.f);
        m_scoreLabel->setScale(.75f);
        this->addChild(m_scoreLabel, 10);

        m_message = CCLabelBMFont::create("TAP / CLICK / SPACE TO FLAP", "bigFont.fnt");
        m_message->setPosition(win.width / 2.f, win.height * .22f);
        m_message->setScale(.45f);
        this->addChild(m_message, 10);

        auto menu = CCMenu::create();
        menu->setPosition(0, 0);
        this->addChild(menu, 20);
        m_buttons = menu;

        auto backLabel = CCLabelBMFont::create("BACK", "bigFont.fnt");
        backLabel->setScale(.5f);
        auto back = CCMenuItemLabel::create(backLabel, this, menu_selector(BirdGameLayer::onBack));
        back->setPosition(70, win.height - 35.f);
        menu->addChild(back);

        this->resetRun();
        return true;
    }

    void resetRun() {
        auto win = CCDirector::sharedDirector()->getWinSize();
        m_pipes.clear();
        m_birdY = win.height * .52f;
        m_velocity = 0;
        m_spawnTimer = 0;
        m_score = 0;
        m_started = false;
        m_dead = false;
        if (m_bird) m_bird->setPosition(kBirdX, m_birdY);
        if (m_scoreLabel) m_scoreLabel->setString("0");
        if (m_message) {
            m_message->setString("TAP / CLICK / SPACE TO FLAP");
            m_message->setVisible(true);
        }
        this->redrawPipes();
    }

    void flap() {
        if (m_dead) {
            resetRun();
            return;
        }
        m_started = true;
        m_velocity = kFlap;
        if (m_message) m_message->setVisible(false);
    }

    void spawnPipe() {
        auto win = CCDirector::sharedDirector()->getWinSize();
        float minY = 160.f + kGap / 2.f;
        float maxY = win.height - 110.f - kGap / 2.f;
        float t = static_cast<float>(m_pipes.size() * 37 % 100) / 100.f;
        float gapY = minY + (maxY - minY) * t;
        m_pipes.push_back({win.width + kPipeWidth, gapY, false});
    }

    void redrawPipes() {
        if (!m_world) return;
        std::vector<CCNode*> remove;
        for (auto child : CCArrayExt<CCNode*>(m_world->getChildren())) {
            if (child != m_bird) remove.push_back(child);
        }
        for (auto n : remove) n->removeFromParentAndCleanup(true);

        auto win = CCDirector::sharedDirector()->getWinSize();
        for (auto const& p : m_pipes) {
            auto top = CCLayerColor::create(ccColor4B{70, 190, 75, 255}, kPipeWidth, p.gapY + kGap / 2.f);
            top->setPosition(p.x, p.gapY + kGap / 2.f);
            m_world->addChild(top, 2);
            auto bottomH = p.gapY - kGap / 2.f;
            auto bottom = CCLayerColor::create(ccColor4B{70, 190, 75, 255}, kPipeWidth, bottomH);
            bottom->setPosition(p.x, 55.f);
            m_world->addChild(bottom, 2);
        }
    }

    CCRect birdRect() const {
        return CCRect(kBirdX - kBirdSize / 2.f, m_birdY - kBirdSize / 2.f, kBirdSize, kBirdSize);
    }

    void die() {
        if (m_dead) return;
        m_dead = true;
        m_started = false;
        if (m_message) {
            m_message->setString("GAME OVER - TAP TO RETRY");
            m_message->setVisible(true);
        }
    }

    void update(float dt) override {
        if (!m_started || m_dead) return;
        dt = std::min(dt, .033f);
        auto win = CCDirector::sharedDirector()->getWinSize();
        m_velocity += kGravity * dt;
        m_birdY += m_velocity * dt;
        if (m_bird) {
            m_bird->setPosition(kBirdX, m_birdY);
            m_bird->setRotation(std::max(-25.f, std::min(90.f, -m_velocity * .08f)));
        }

        if (m_birdY < 70.f || m_birdY > win.height - 30.f) {
            die();
            return;
        }

        m_spawnTimer += dt;
        if (m_spawnTimer >= 1.35f) {
            m_spawnTimer = 0;
            spawnPipe();
        }

        for (auto& p : m_pipes) {
            p.x -= m_speed * dt;
            CCRect top(p.x, p.gapY + kGap / 2.f, kPipeWidth, win.height - (p.gapY + kGap / 2.f));
            CCRect bottom(p.x, 55.f, kPipeWidth, p.gapY - kGap / 2.f - 55.f);
            if (birdRect().intersectsRect(top) || birdRect().intersectsRect(bottom)) {
                die();
                return;
            }
            if (!p.scored && p.x + kPipeWidth < kBirdX) {
                p.scored = true;
                ++m_score;
                if (m_scoreLabel) m_scoreLabel->setString(std::to_string(m_score).c_str());
            }
        }

        while (!m_pipes.empty() && m_pipes.front().x + kPipeWidth < -20.f)
            m_pipes.erase(m_pipes.begin());
        redrawPipes();
    }

    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        if (!this->isVisible()) return false;
        flap();
        return true;
    }

    void ccTouchesBegan(CCSet*, CCEvent*) override { flap(); }

    void onBack(CCObject*) {
        this->removeFromParentAndCleanup(true);
    }

public:
    static BirdGameLayer* create() {
        auto ret = new BirdGameLayer();
        if (ret && ret->init()) { ret->autorelease(); return ret; }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

class $modify(FlappyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto label = CCLabelBMFont::create("BIRD?", "bigFont.fnt");
        label->setScale(.48f);
        auto button = CCMenuItemLabel::create(label, this, menu_selector(FlappyMenuLayer::onBird));
        button->setID("flappy-maker-bird-button");

        auto menu = CCMenu::create();
        menu->addChild(button);
        menu->setPosition(0, 0);
        this->addChild(menu, 50);

        auto win = CCDirector::sharedDirector()->getWinSize();
        button->setPosition(win.width - 80.f, 65.f);
        return true;
    }

    void onBird(CCObject*) {
        auto scene = CCDirector::sharedDirector()->getRunningScene();
        if (!scene) return;
        if (scene->getChildByTag(982341)) return;
        auto layer = BirdGameLayer::create();
        if (!layer) return;
        layer->setTag(982341);
        scene->addChild(layer, 999);
    }
};

} // namespace flappy
